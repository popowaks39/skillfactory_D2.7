from django.db import models
from django.contrib.auth.models import User
from django.db.models import Avg, Count, Min, Sum

class Author(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rating = models.IntegerField(default=0)
    
    def update_rating(self):
        post_rating = 0
        com_rating = 0
        post_com_rating = 0
        
        post_rating = self.post_set.aggregate(Sum('rating'))['rating__sum']*3

        com_rating = self.user.comment_set.all().aggregate(Sum('rating'))['rating__sum']

        post_com_rating = self.post_set.all().aggregate(Sum('comment__rating'))['comment__rating__sum']

        self.rating = post_rating + com_rating + post_com_rating
        self.save()

        return self.rating

class Category(models.Model):
    name = models.CharField(max_length=255, unique=True)

class Post(models.Model):
    author = models.ForeignKey('Author', on_delete=models.CASCADE)
    is_news = models.BooleanField(default=True)
    date_add = models.DateTimeField(auto_now_add=True)
    category = models.ManyToManyField('Category', through='PostCategory')
    title = models.CharField(max_length=255)
    text = models.TextField()
    rating = models.IntegerField(default=0)
    
    def like(self):
        self.rating += 1
        self.save()

    def dislike(self):
        self.rating -= 1
        self.save()
        
    def preview(self):
        return self.text[:124] + "..."

class PostCategory(models.Model):
    post = models.ForeignKey('Post', on_delete=models.CASCADE)
    category = models.ForeignKey('Category', on_delete=models.CASCADE)

class Comment(models.Model):
    post = models.ForeignKey('Post', on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    text = models.TextField()
    date_add = models.DateTimeField(auto_now_add=True)
    rating = models.IntegerField(default=0)
    
    def like(self):
        self.rating += 1
        self.save()

    def dislike(self):
        self.rating -= 1
        self.save()